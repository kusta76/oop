#include <iostream>
#include "Time.h"
using namespace std;
int main() {
	Time A, B(14), C(18, 23);
	A.Dispay();
	B.Dispay();
	C.Dispay();
	Time a, b, c, d, e, f;
	bool f1, f2, f3;
	int seconds = 3600;
	a = a.secondsInit(86399);
	a.Dispay();
	b.timeInit(a);
	b.Dispay();
	c = c.Init(22, 1, 1);
	c.Dispay();
	a.Difference(c);
	d = a.timeAdd(c);
	d.ToString();
	e = c + seconds;
	e.ToString();
	f = e.Sub(seconds);
	f.ToString();
	f1 = e > f;
	f2 = e < f;
	f3 = a == b;
	cout << f1 << " " << f2 << " " << f3 << endl;
	a = a.textInit("15:30:36");
	a.Dispay();
	b.Read();
	b.Dispay();
	a.toSeconds();
	b.toMinutes();
}