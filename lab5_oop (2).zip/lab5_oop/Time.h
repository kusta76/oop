#pragma once
#include <string>
using namespace std;
class Time
{
	int hours;
	int minutes;
	int seconds;
public:
	void Read();
	void Dispay();
	Time Init(int h, int m, int s);
	Time textInit(string t);
	Time secondsInit(int seconds);
	void timeInit(Time m1);
	void Difference(Time m1);
	Time timeAdd(Time m1);
	Time operator +(int second);
	Time Sub(int second);
	bool operator >(Time m1);
	bool operator <(Time m1);
	bool operator ==(Time m1);
	void toSeconds();
	void toMinutes();
	void ToString();
	Time();
	Time(int h);
	Time(int h, int m);
};