#include "Time.h"
#include <iostream>
#include <string>
#include <cmath>
#include <sstream>
using namespace std;

void Time::Read()
{
	cout << "Enter hours ";
	cin >> hours;
	cout << "Enter minutes ";
	cin >> minutes;
	cout << "Enter seconds ";
	cin >> seconds;
	cout << endl;
}

void Time::Dispay()
{
	cout << "Hours = " << hours << ", minutes = " << minutes << ", seconds = " << seconds << endl;
	cout << endl;
}

Time Time::Init(int h, int m, int s)
{
	Time temp;
	temp.hours = h;
	temp.minutes = m;
	temp.seconds = s;
	return temp;
}

Time Time::textInit(string t)
{
	Time temp;
	int h, m, s;
	char colon;
	stringstream ss(t);
	ss >> h >> colon >> m >> colon >> s;
	temp.hours = h;
	temp.minutes = m;
	temp.seconds = s;
	return temp;
}

Time Time::secondsInit(int seconds)
{
	Time temp;
	int h, m, s;
	h = seconds / 3600;
	m = (seconds % 3600) / 60;
	s = seconds % 60;
	temp.hours = h;
	temp.minutes = m;
	temp.seconds = s;
	return temp;
}

void Time::timeInit(Time m1)
{
	hours = m1.hours;
	minutes = m1.minutes;
	seconds = m1.seconds;
}

void Time::Difference(Time m1)
{
	int seconds1, seconds2, difference;
	seconds1 = (this->hours * 3600) + (this->minutes * 60) + this->seconds;
	seconds2 = (m1.hours * 3600) + (m1.minutes * 60) + m1.seconds;
	difference = abs(seconds1 - seconds2);
	cout << "Difference is " << difference << " seconds" << endl;
	cout << endl;
}

Time Time::timeAdd(Time m1)
{
	Time temp;
	temp.hours = this->hours + m1.hours;
	temp.minutes = this->minutes + m1.minutes;
	temp.seconds = this->seconds + m1.seconds;
	return temp;
}

Time Time::operator+(int second)
{
	Time temp;
	int h, m, s;
	h = second / 3600;
	m = (second % 3600) / 60;
	s = second % 60;
	temp.hours = hours + h;
	temp.minutes = minutes + m;
	temp.seconds = seconds + s;
	return temp;
}

Time Time::Sub(int second)
{
	Time temp;
	int h, m, s;
	h = second / 3600;
	m = (second % 3600) / 60;
	s = second % 60;
	temp.hours = hours - h;
	temp.minutes = minutes - m;
	temp.seconds = seconds - s;
	return temp;
}

bool Time::operator>(Time m1)
{
	int s1, s2;
	s1 = (this->hours * 3600) + (this->minutes * 60) + this->seconds;
	s2 = (m1.hours * 3600) + (m1.minutes * 60) + m1.seconds;
	return s1 > s2;
}

bool Time::operator<(Time m1)
{
	int s1, s2;
	s1 = (this->hours * 3600) + (this->minutes * 60) + this->seconds;
	s2 = (m1.hours * 3600) + (m1.minutes * 60) + m1.seconds;
	return s1 < s2;
}

bool Time::operator==(Time m1)
{
	int s1, s2;
	s1 = (this->hours * 3600) + (this->minutes * 60) + this->seconds;
	s2 = (m1.hours * 3600) + (m1.minutes * 60) + m1.seconds;
	return s1 == s2;
}

void Time::toSeconds()
{
	int s;
	s = (hours * 3600) + (minutes * 60) + seconds;
	cout << "Time in seconds " << s << endl;
	cout << endl;
}

void Time::toMinutes()
{
	int m;
	m = (hours * 60) + minutes + (seconds / 60);
	cout << "Time in minutes " << m << endl;
	cout << endl;
}

void Time::ToString()
{
	cout << "Time after operation is " << to_string(hours) << " hours " << to_string(minutes) << " minutes " << to_string(seconds) << " seconds" << endl;
	cout << endl;
}

Time::Time()
{
	hours = 12;
	minutes = 50;
	seconds = 21;
}

Time::Time(int h)
{
	hours = h;
	minutes = 28;
	seconds = 45;
}

Time::Time(int h, int m)
{
	hours = h;
	minutes = m;
	seconds = 30;
}